<?php

class theme_overridetest_core_renderer extends core_renderer
{
    
}